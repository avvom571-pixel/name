-- ILM ACADEMY PRO initial schema
-- Apply in Supabase SQL Editor after creating a project.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  preferred_language text not null default 'uz' check (preferred_language in ('uz','ky','ru')),
  country_code text,
  created_at timestamptz not null default now()
);

create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  status text not null default 'draft' check (status in ('draft','published','archived')),
  level text not null default 'beginner',
  cover_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.course_translations (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  language text not null check (language in ('uz','ky','ru')),
  title text not null,
  description text not null default '',
  unique(course_id, language)
);

create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  position integer not null,
  content_type text not null default 'text' check (content_type in ('text','audio','video','pdf','interactive')),
  media_path text,
  is_free boolean not null default false,
  published boolean not null default false,
  unique(course_id, position)
);

create table if not exists public.lesson_translations (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  language text not null check (language in ('uz','ky','ru')),
  title text not null,
  body jsonb not null default '{}'::jsonb,
  unique(lesson_id, language)
);

create table if not exists public.enrollments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  enrolled_at timestamptz not null default now(),
  unique(user_id, course_id)
);

create table if not exists public.lesson_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  completed_at timestamptz,
  updated_at timestamptz not null default now(),
  unique(user_id, lesson_id)
);

create table if not exists public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  score numeric(5,2) not null,
  answers jsonb not null default '[]'::jsonb,
  submitted_at timestamptz not null default now()
);

create table if not exists public.entitlements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_code text not null,
  source text not null check (source in ('google_play','web_payment','admin_grant','coupon')),
  status text not null check (status in ('active','expired','revoked')),
  starts_at timestamptz not null default now(),
  ends_at timestamptz,
  external_reference text,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.course_translations enable row level security;
alter table public.lessons enable row level security;
alter table public.lesson_translations enable row level security;
alter table public.enrollments enable row level security;
alter table public.lesson_progress enable row level security;
alter table public.quiz_attempts enable row level security;
alter table public.entitlements enable row level security;

create policy "profiles_select_own" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profiles_update_own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "published_courses_read" on public.courses for select using (status = 'published');
create policy "course_translations_read" on public.course_translations for select using (
  exists (select 1 from public.courses c where c.id = course_id and c.status = 'published')
);
create policy "published_lessons_read" on public.lessons for select using (
  published = true and exists (select 1 from public.courses c where c.id = course_id and c.status = 'published')
);
create policy "lesson_translations_read" on public.lesson_translations for select using (
  exists (select 1 from public.lessons l join public.courses c on c.id = l.course_id
    where l.id = lesson_id and l.published = true and c.status = 'published')
);
create policy "enrollments_read_own" on public.enrollments for select to authenticated using (user_id = auth.uid());
create policy "progress_read_own" on public.lesson_progress for select to authenticated using (user_id = auth.uid());
create policy "progress_insert_own" on public.lesson_progress for insert to authenticated with check (user_id = auth.uid());
create policy "progress_update_own" on public.lesson_progress for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "quiz_attempts_read_own" on public.quiz_attempts for select to authenticated using (user_id = auth.uid());
create policy "quiz_attempts_insert_own" on public.quiz_attempts for insert to authenticated with check (user_id = auth.uid());
create policy "entitlements_read_own" on public.entitlements for select to authenticated using (user_id = auth.uid());

-- IMPORTANT:
-- Never put the Supabase service_role key in a browser or mobile app.
-- Payment entitlement writes must be performed by a trusted server/webhook,
-- not by a client-side request.
