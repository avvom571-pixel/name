# ILM ACADEMY PRO — MVP starter

A responsive multilingual education-platform starter (Uzbek, Kyrgyz, Russian), prepared for a shared web + Android codebase. Version 0.2 adds both learning tracks and a full demo administration workspace.

## Current status

Included:
- Responsive React + TypeScript web app
- Uzbek / Kyrgyz / Russian language switcher
- Course catalogue with search
- Course detail and demo lesson outline
- Mabdaul Qiroat books 1, 2, 3 learning track
- Nahw and Sarf learning track
- Admin workspace: overview, course management, students, teachers, payments and content tabs
- Demo-only add-course interaction
- PWA manifest
- Capacitor Android configuration
- Supabase client placeholder
- Initial PostgreSQL schema and row-level security policies

Not yet included:
- Real user registration / password recovery
- Admin content management
- Real lesson content, audio, video and PDF
- Working quizzes and progress persistence
- Payment provider integration and verified subscription entitlements
- AdMob integration
- Production privacy policy, terms and store assets

The visible courses and lessons are demo placeholders, not complete educational content.

## Requirements

- Node.js 20.19+ or 22.12+
- npm
- Android Studio only when building the Android app

## Run locally

```bash
npm install
cp .env.example .env
npm run dev
```

The app works in demo mode without Supabase credentials.

## v0.2 database migration

After running `supabase/schema.sql`, run `supabase/v0.2-admin-migration.sql` in Supabase SQL Editor. The migration adds staff roles, programs, quizzes, certificates, announcements and audit logs with role-based row-level security. Assign the first `super_admin` manually as shown at the bottom of the migration.

The admin UI in this ZIP is a frontend demonstration, not a production-secure admin system. Do not expose it publicly with privileged access until authentication, server-side role checks, audit logging and policies are tested.

## Connect Supabase

1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Copy Project URL and anon/public key into `.env`.
4. Restart the dev server.

Only use the anon/public key in the client. Never expose `service_role`.

## Build web

```bash
npm run build
npm run preview
```

## Build Android

```bash
npm run cap:add:android
npm run cap:sync
npm run cap:open
```

In Android Studio, configure app signing and test on physical devices. For Google Play, create a signed Android App Bundle (AAB), not just a debug APK.

## Monetization architecture

Use a server-side entitlement model:
- `entitlements` is the single source of truth for paid access.
- A trusted backend validates payment receipts / provider webhooks.
- The client only reads the current user's entitlements.
- Do not grant Premium access based only on a client-side success screen.

For launch from Kyrgyzstan, verify merchant-country eligibility, payout availability, tax obligations and the selected payment provider before implementing checkout. Keep the payment integration behind a provider adapter so it can be changed without rebuilding course logic.

## Current limitations

- Dashboard figures and sample students/teachers/payments are illustrative demo data, not live business metrics.
- Adding a course in the demo changes browser memory only; it is not persisted to the database yet.
- Real course texts, audio, PDF and video must be supplied/licensed and entered by the academy.
- Authentication, server APIs, admin writes, payment verification, quiz grading and certificate generation still need implementation and security testing.

## Recommended next milestones

1. Agree final product name, target language defaults and course syllabus.
2. Add secure authentication and user profile creation.
3. Build admin CMS for lessons and translations.
4. Implement lesson reader, audio player, quizzes and progress tracking.
5. Select and legally verify web payment provider(s).
6. Add AdMob only after privacy disclosures and consent flow are ready.
7. Prepare Play Store listing, privacy policy, screenshots and signed AAB.


## v0.3 — Authentication and access control

This release adds an email/password sign-in and sign-up screen when Supabase is configured. New accounts receive the `student` role automatically. The administration menu is shown only to accounts with `admin` or `super_admin` in `public.user_roles`; the database must enforce the same permissions with RLS.

### Supabase setup order
1. Create a Supabase project.
2. Run `supabase/schema.sql`.
3. Run `supabase/v0.2-admin-migration.sql`.
4. Run `supabase/v0.3-security-auth.sql`.
5. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` to `.env` (use the project URL and anon/public key only).
6. Register your own account in the app. In Supabase SQL Editor, find its UUID under Authentication → Users, then run:
   `insert into public.user_roles(user_id, role) values ('YOUR-USER-UUID', 'super_admin') on conflict do nothing;`
7. Sign out and sign in again. The admin menu should appear.

Never put the Supabase `service_role` key in `.env` for this frontend, website, or APK. Payment validation and privileged operations must run on a trusted server.

### Current limitations
- Admin lists and course creation are still demo/local UI; they are not yet connected to persistent CRUD endpoints. Do not treat the displayed demo numbers or sample students as real data.
- The seven course entries are course catalog shells, not the full contents of Mabdaul Qiroat or a complete Nahw/Sarf textbook. To build faithful lessons, upload the exact source PDFs/audio or provide the lesson texts.
- The SQL migrations have not been executed against your Supabase project. Review and run them in order; test with separate student and admin accounts before publishing.
- Payment checkout, Google Play Billing verification, certificates, quiz grading, and Android APK/AAB packaging are not production-ready in this source release.
- Build verification could not be completed in this environment because dependency installation timed out. Run `npm install` and `npm run build` on your computer and share any error output.


## v0.4 — Mabdaul Qiroat 3 platform connection

The uploaded `Mabdal 3.apk` was inspected. It is a Median web-wrapper APK, not a standalone source-code project: its configured initial URL is `https://avvom571-pixel.github.io/Mabdal3/` and its app label is `Мабдаъ ул-қироат 3`. The academy now includes a dedicated sidebar page that embeds this existing website, plus a fallback button to open it in a new browser tab. The Mabdaul Qiroat 3 course detail also links to the connected platform.

Important: the APK binary itself is not merged into the React project. The web platform is linked/embedded from its published URL; its lesson database, login, and progress are not yet unified with ILM ACADEMY's Supabase backend. Some websites may block iframe embedding; use the external-open button if the embedded view is blank.


### v0.4 — first persistent admin operation

When Supabase is configured and the signed-in account has the `admin` or `super_admin` role, the admin page now loads course rows from `public.courses` with their `course_translations`. Creating a course inserts a draft course and an Uzbek translation; if translation insertion fails, the newly created course row is rolled back. Without Supabase, the app remains in demo mode and clearly reports that the item is only held in local browser state. This is the first persisted CMS operation; lesson authoring, student management, teacher assignments, payment operations and media uploads are still pending.

## Real content and business direction (v0.5 work-in-progress)

- `CONTENT_STANDARDS.md` defines source citation, Arabic-text verification, teacher review and copyright checks before lessons can be published.
- `BUSINESS_MODEL.md` defines the initial price hypotheses, $1,000 gross-revenue arithmetic, 90-day validation plan and Kyrgyzstan payment-provider shortlist. Prices are experiments, not confirmed market rates.
- The app now includes five authored starter lessons for Nahw/Sarf with Arabic examples and formative quiz questions. These are learning drafts requiring qualified teacher review before paid/public release.
- Mabdaul Qiroat book-specific lessons remain source-dependent. The supplied APK is a WebView wrapper whose initial URL points to the hosted Mabdal3 website; the APK itself does not contain the website's lesson content. Supply the source PDFs or exportable site content to build accurate lessons.
- Admin statistics must show only real database/payment records; no fabricated learner or activity counts should be used.
- The v0.3 security SQL now removes public direct access to quiz answer keys and provides server-side quiz question retrieval and grading RPC functions. Test these migrations on a fresh Supabase project before production.


## v0.5 content-first update

- Five starter lessons are available in the Nahw/Sarf courses with Arabic examples, explanations and short knowledge checks.
- Mabdaul Qiroat lessons are deliberately marked as source-required until the original book pages are supplied.
- Admin dashboard no longer displays fabricated student/activity counts.
- Review `BUSINESS_MODEL.md` and `CONTENT_STANDARDS.md` before accepting payments or publishing paid material.
- Apply SQL files in order: `schema.sql`, `v0.2-admin-migration.sql`, then `v0.3-security-auth.sql`. The SQL has not been run against your Supabase project; test on a fresh project first.


## v0.6 — user-provided Mabdaul Qiroat HTML integrated locally

- The uploaded `Мабдаъ ул-қироат — Луғат.html` is now bundled at `public/mabdaul-qiroat/index.html`; the Academy embeds this local copy instead of relying on a remote iframe.
- Source HTML includes 57 vocabulary lesson groups, 819 vocabulary entries, 58 reading-text lessons, flashcards, direction-based quizzes, a timed exam, text comprehension test, review, favorites, daily goal and theme/font settings.
- The HTML source itself says the vocabulary is from the glossary at the end of Mabdaul Qiroat book 3 (pages 91–111), and that its Uzbek reading-text translations were made by the site creator rather than being an official translation. Verify Arabic and Uzbek text with a qualified teacher before charging for access.
- Learner progress in this imported HTML still uses browser `localStorage`; it is not yet synced to Academy accounts or Supabase. The imported page is available for free access during the first launch phase.
- Build could not be verified in this environment because `node_modules` is empty/incomplete. Run `npm install` then `npm run build` locally.
