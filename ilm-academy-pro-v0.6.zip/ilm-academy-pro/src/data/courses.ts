export type Course = {
  id: string;
  title: string;
  category: string;
  level: string;
  lessons: number;
  duration: string;
  description: string;
  color: string;
  progress: number;
  program: string;
};

// Lesson counts reflect content currently present in this build, not the future syllabus.
export const courses: Course[] = [
  { id: "mabda-1", title: "Мабдаъул Қироат — 1-китоб", category: "Қироат", level: "Бошланғич", lessons: 0, duration: "Манба кутилмоқда", description: "Китобнинг асл PDF/саҳифалари асосида тайёрланади: арабча матн, луғат, талаффуз ва машқлар.", color: "mint", progress: 0, program: "Мабдаъул Қироат" },
  { id: "mabda-2", title: "Мабдаъул Қироат — 2-китоб", category: "Қироат", level: "Бошланғич+", lessons: 0, duration: "Манба кутилмоқда", description: "Иккинчи китобнинг дарслари манба билан солиштирилгандан кейин жойланади.", color: "sand", progress: 0, program: "Мабдаъул Қироат" },
  { id: "mabda-3", title: "Мабдаъул Қироат — 3-китоб", category: "Қироат", level: "Ўрта", lessons: 57, duration: "57 луғат дарси · 819 сўз · 58 матн", description: "Сиз юборган HTML манбадаги 57 луғат дарсидаги 819 та сўз, карточкалар, тест, имтиҳон, такрорлаш ва 58 та матн бўлими академия ичига бирлаштирилди.", color: "lavender", progress: 0, program: "Мабдаъул Қироат" },
  { id: "nahw-intro", title: "Наҳв илмига кириш", category: "Грамматика", level: "Бошланғич", lessons: 3, duration: "Намуна дарслар", description: "Калом, исм-феъл-ҳарф ва исм аломатлари бўйича 3 та текширув талаб қиладиган намунавий дарс.", color: "blue", progress: 0, program: "Наҳв ва Сарф" },
  { id: "nahw-advanced", title: "Наҳв: иъроб ва жумлалар", category: "Грамматика", level: "Ўрта", lessons: 0, duration: "Тайёрланмоқда", description: "Иъроб, омиллар, марфуъот, мансубот ва арабча жумлалар таҳлили.", color: "mint", progress: 0, program: "Наҳв ва Сарф" },
  { id: "sarf-intro", title: "Сарф илмига кириш", category: "Грамматика", level: "Бошланғич", lessons: 2, duration: "Намуна дарслар", description: "Сарфнинг вазифаси, илдиз-вазн, мозий ва музореъ бўйича 2 та намунавий дарс.", color: "sand", progress: 0, program: "Наҳв ва Сарф" },
  { id: "sarf-advanced", title: "Сарф: феъллар таҳлили", category: "Грамматика", level: "Ўрта", lessons: 0, duration: "Тайёрланмоқда", description: "Феъл боблари, масдар, исми фоил, исми мафъул ва амалий таҳлил.", color: "lavender", progress: 0, program: "Наҳв ва Сарф" }
];
