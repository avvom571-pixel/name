-- ILM ACADEMY PRO v0.3: account bootstrap + secure role-aware access.
-- Run after schema.sql and v0.2-admin-migration.sql in Supabase SQL Editor.

-- Create a profile automatically for every newly registered account.
create or replace function public.handle_new_academy_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)))
  on conflict (id) do nothing;
  insert into public.user_roles(user_id, role) values (new.id, 'student') on conflict do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_academy on auth.users;
create trigger on_auth_user_created_academy
after insert on auth.users for each row execute procedure public.handle_new_academy_user();

create or replace function public.has_academy_role(required_roles text[])
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (select 1 from public.user_roles ur where ur.user_id = auth.uid() and ur.role = any(required_roles));
$$;
revoke all on function public.has_academy_role(text[]) from public;
grant execute on function public.has_academy_role(text[]) to authenticated;

-- Explicitly remove policies from earlier migration so this file can be re-run.
drop policy if exists profiles_admin_read on public.profiles;
drop policy if exists profiles_admin_update on public.profiles;
drop policy if exists roles_read_self_or_admin on public.user_roles;
drop policy if exists admins_manage_roles on public.user_roles;
drop policy if exists published_programs_read on public.programs;
drop policy if exists admins_manage_programs on public.programs;
drop policy if exists program_translations_read on public.program_translations;
drop policy if exists admins_manage_program_translations on public.program_translations;
drop policy if exists admins_manage_courses on public.courses;
drop policy if exists admins_manage_course_translations on public.course_translations;
drop policy if exists staff_manage_lessons on public.lessons;
drop policy if exists staff_manage_lesson_translations on public.lesson_translations;
drop policy if exists published_quizzes_read on public.quizzes;
drop policy if exists staff_manage_quizzes on public.quizzes;
drop policy if exists published_quiz_questions_read on public.quiz_questions;
drop policy if exists staff_manage_quiz_questions on public.quiz_questions;
drop policy if exists certificates_read_own_or_admin on public.certificates;
drop policy if exists admins_issue_certificates on public.certificates;
drop policy if exists published_announcements_read on public.announcements;
drop policy if exists admins_manage_announcements on public.announcements;
drop policy if exists admins_read_audit_logs on public.audit_logs;
drop policy if exists admins_write_audit_logs on public.audit_logs;

create policy profiles_admin_read on public.profiles for select to authenticated
using (id = auth.uid() or public.has_academy_role(array['admin','super_admin','teacher']));
create policy profiles_admin_update on public.profiles for update to authenticated
using (id = auth.uid() or public.has_academy_role(array['admin','super_admin']))
with check (id = auth.uid() or public.has_academy_role(array['admin','super_admin']));

create policy roles_read_self_or_admin on public.user_roles for select to authenticated
using (user_id = auth.uid() or public.has_academy_role(array['admin','super_admin']));
create policy admins_manage_roles on public.user_roles for all to authenticated
using (public.has_academy_role(array['super_admin'])) with check (public.has_academy_role(array['super_admin']));

create policy published_programs_read on public.programs for select to anon, authenticated
using (exists (select 1 from public.courses c where c.program_id = id and c.status = 'published'));
create policy admins_manage_programs on public.programs for all to authenticated
using (public.has_academy_role(array['admin','super_admin'])) with check (public.has_academy_role(array['admin','super_admin']));
create policy program_translations_read on public.program_translations for select to anon, authenticated using (true);
create policy admins_manage_program_translations on public.program_translations for all to authenticated
using (public.has_academy_role(array['admin','super_admin'])) with check (public.has_academy_role(array['admin','super_admin']));

create policy admins_manage_courses on public.courses for all to authenticated
using (public.has_academy_role(array['admin','super_admin']) or (public.has_academy_role(array['teacher']) and teacher_id = auth.uid()))
with check (public.has_academy_role(array['admin','super_admin']) or (public.has_academy_role(array['teacher']) and teacher_id = auth.uid()));
create policy admins_manage_course_translations on public.course_translations for all to authenticated
using (public.has_academy_role(array['admin','super_admin'])) with check (public.has_academy_role(array['admin','super_admin']));
create policy staff_manage_lessons on public.lessons for all to authenticated
using (public.has_academy_role(array['admin','super_admin']) or exists (select 1 from public.courses c where c.id = course_id and c.teacher_id = auth.uid() and public.has_academy_role(array['teacher'])))
with check (public.has_academy_role(array['admin','super_admin']) or exists (select 1 from public.courses c where c.id = course_id and c.teacher_id = auth.uid() and public.has_academy_role(array['teacher'])));
create policy staff_manage_lesson_translations on public.lesson_translations for all to authenticated
using (public.has_academy_role(array['admin','super_admin']) or exists (select 1 from public.lessons l join public.courses c on c.id=l.course_id where l.id=lesson_id and c.teacher_id=auth.uid() and public.has_academy_role(array['teacher'])))
with check (public.has_academy_role(array['admin','super_admin']) or exists (select 1 from public.lessons l join public.courses c on c.id=l.course_id where l.id=lesson_id and c.teacher_id=auth.uid() and public.has_academy_role(array['teacher'])));
create policy published_quizzes_read on public.quizzes for select to anon, authenticated using (published = true);
create policy staff_manage_quizzes on public.quizzes for all to authenticated
using (public.has_academy_role(array['admin','super_admin','teacher'])) with check (public.has_academy_role(array['admin','super_admin','teacher']));
create policy published_quiz_questions_read on public.quiz_questions for select to anon, authenticated
using (exists (select 1 from public.quizzes q where q.id = quiz_id and q.published = true));
create policy staff_manage_quiz_questions on public.quiz_questions for all to authenticated
using (public.has_academy_role(array['admin','super_admin','teacher'])) with check (public.has_academy_role(array['admin','super_admin','teacher']));
create policy certificates_read_own_or_admin on public.certificates for select to authenticated
using (user_id = auth.uid() or public.has_academy_role(array['admin','super_admin','teacher']));
create policy admins_issue_certificates on public.certificates for insert to authenticated
with check (public.has_academy_role(array['admin','super_admin']));
create policy published_announcements_read on public.announcements for select to anon, authenticated using (published = true);
create policy admins_manage_announcements on public.announcements for all to authenticated
using (public.has_academy_role(array['admin','super_admin'])) with check (public.has_academy_role(array['admin','super_admin']));
create policy admins_read_audit_logs on public.audit_logs for select to authenticated
using (public.has_academy_role(array['admin','super_admin']));
create policy admins_write_audit_logs on public.audit_logs for insert to authenticated
with check (public.has_academy_role(array['admin','super_admin']));

-- Private media bucket. Create only once; access policies are role-controlled.
insert into storage.buckets(id, name, public, file_size_limit, allowed_mime_types)
values ('academy-private', 'academy-private', false, 104857600,
  array['audio/mpeg','audio/mp4','application/pdf','video/mp4','image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
drop policy if exists academy_media_read on storage.objects;
drop policy if exists academy_media_staff_upload on storage.objects;
drop policy if exists academy_media_staff_update on storage.objects;
create policy academy_media_read on storage.objects for select to authenticated
using (bucket_id = 'academy-private' and (public.has_academy_role(array['admin','super_admin','teacher']) or exists (
  select 1 from public.lessons l join public.courses c on c.id=l.course_id
  where l.media_path = name and l.published = true and c.status='published'
)));
create policy academy_media_staff_upload on storage.objects for insert to authenticated
with check (bucket_id='academy-private' and public.has_academy_role(array['admin','super_admin','teacher']));
create policy academy_media_staff_update on storage.objects for update to authenticated
using (bucket_id='academy-private' and public.has_academy_role(array['admin','super_admin','teacher']))
with check (bucket_id='academy-private' and public.has_academy_role(array['admin','super_admin','teacher']));

-- After the first account is registered, grant full admin rights using its UUID:
-- insert into public.user_roles(user_id, role) values ('AUTH-USER-UUID', 'super_admin') on conflict do nothing;
-- Keep service_role keys on a trusted server only. Never ship them in the website or APK.

-- SECURITY FIX: never expose answer_key or explanation through a public table SELECT.
-- The public quiz-question policy from v0.2 is intentionally removed.
drop policy if exists published_quiz_questions_read on public.quiz_questions;

create or replace function public.get_published_quiz_questions(p_quiz_id uuid)
returns table (id uuid, position integer, question jsonb, options jsonb)
language sql
stable
security definer
set search_path = public
as $$
  select qq.id, qq.position, qq.question, qq.options
  from public.quiz_questions qq
  join public.quizzes q on q.id = qq.quiz_id
  where qq.quiz_id = p_quiz_id and q.published = true
  order by qq.position;
$$;
revoke all on function public.get_published_quiz_questions(uuid) from public;
grant execute on function public.get_published_quiz_questions(uuid) to anon, authenticated;

-- Grade the full submission on the database side so correct answers are not sent to the client.
create or replace function public.grade_published_quiz(p_quiz_id uuid, p_answers jsonb)
returns table (score numeric, correct_count integer, total_count integer)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_lesson_id uuid;
  v_total integer;
  v_correct integer;
  v_score numeric(5,2);
begin
  if v_user_id is null then
    raise exception 'Authentication required';
  end if;
  if jsonb_typeof(p_answers) <> 'array' then
    raise exception 'Answers must be a JSON array';
  end if;
  select q.lesson_id into v_lesson_id from public.quizzes q where q.id = p_quiz_id and q.published = true;
  if v_lesson_id is null then
    raise exception 'Published quiz not found';
  end if;
  select count(*) into v_total from public.quiz_questions qq where qq.quiz_id = p_quiz_id;
  if v_total = 0 then
    raise exception 'Quiz has no questions';
  end if;
  select count(*) into v_correct
  from public.quiz_questions qq
  join jsonb_to_recordset(p_answers) as submitted(question_id uuid, answer text)
    on submitted.question_id = qq.id and submitted.answer = qq.answer_key
  where qq.quiz_id = p_quiz_id;
  v_score := round((v_correct::numeric / v_total::numeric) * 100, 2);
  insert into public.quiz_attempts(user_id, lesson_id, score, answers)
  values (v_user_id, v_lesson_id, v_score, p_answers);
  return query select v_score, v_correct, v_total;
end;
$$;
revoke all on function public.grade_published_quiz(uuid, jsonb) from public;
grant execute on function public.grade_published_quiz(uuid, jsonb) to authenticated;
