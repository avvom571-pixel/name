# ILM ACADEMY PRO 0.6

## Integrated source content

The uploaded HTML file `Мабдаъ ул-қироат — Луғат.html` is bundled into the Academy at `/mabdaul-qiroat/index.html` and embedded in the course page. It is no longer dependent on the remote Mabdal3 iframe for this material.

Included from the source HTML: 57 vocabulary lesson groups, 819 vocabulary entries, 58 reading-text lessons, flashcards, quizzes, timed exam, text quiz, spaced review, favorites, daily goals, theme and Arabic font-size controls.

## Important limits

- This is the user-provided HTML source, not a newly verified edition of the printed book.
- The source itself identifies its Uzbek reading-text translations as site-author translations, not official book translations. Teacher review is required before paid release.
- Progress is stored locally in the browser using localStorage. It does not yet sync across devices or Academy accounts.
- The original HTML references Google Fonts; offline font fallback is available through the browser's serif fonts.
- `npm run build` could not be completed in this environment because project dependencies are not installed.
