# ILM ACADEMY PRO v0.5 — content-first update

## What changed
- Replaced generic lesson placeholders in course pages with five authored Nahw/Sarf starter lessons, Arabic examples, short quizzes and explanations.
- Added source notes and a visible requirement for qualified teacher review before public/paid release.
- Mabdaul Qiroat courses no longer pretend to contain copied textbook lessons. They clearly request original book sources; Mabdal3 APK is identified as a WebView wrapper to the hosted site.
- Course counts now show only currently authored lesson units; planned lessons are not counted as published lessons.
- Removed fabricated admin learner and activity metrics; real revenue remains zero until verified payment integration exists.
- Added business model, initial pricing hypotheses, $1,000 gross revenue arithmetic, a 90-day validation plan, Kyrgyz payment-provider shortlist and content quality standards.
- Hardened quiz database access: public clients should fetch quiz prompts without answer keys and submit answers for server-side grading.

## Not yet production-ready
- Dependencies could not be installed in the build environment because `npm install` timed out; a complete Vite/TypeScript production build was not verified.
- Lesson completion is currently in-memory for the current session; it is not yet synced to Supabase.
- Nahw/Sarf sample lessons need qualified teacher review and additional exercises before being sold as a complete course.
- Mabdaul Qiroat 1/2/3 need source PDFs or exportable original website content before exact book lessons can be prepared.
- Supabase SQL migrations have not been run against the owner's project; test on a fresh project and review before production.
- No payment provider is connected and no real purchase can be made from this release.
- Google Play Billing, privacy policy, Data Safety and account deletion requirements must be completed before Play Store release.
