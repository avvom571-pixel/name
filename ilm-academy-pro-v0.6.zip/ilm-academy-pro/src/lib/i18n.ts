export type Language = "uz" | "ky" | "ru";
export const translations = {
  uz: {
    home: "Бош саҳифа", courses: "Курслар", library: "Кутубхона", progress: "Натижалар",
    profile: "Профиль", welcome: "Илм олишни бугун бошланг", subtitle: "Босқичма-босқич ўрганинг, машқ қилинг ва натижангизни кузатинг.",
    explore: "Курсларни кўриш", featured: "Тавсия этилган курслар", all: "Барча курслар",
    continue: "Ўқишни давом эттириш", lessons: "дарс", beginner: "Бошланғич", intermediate: "Ўрта",
    arabic: "Араб тили", grammar: "Араб грамматикаси", reading: "Қироат ва ўқиш",
    tests: "Тестлар", certificate: "Сертификат", free: "Бепул", start: "Бошлаш",
    search: "Курс ёки дарс қидириш...", demo: "Демо режим", backend: "Сервер ҳали уланмаган"
  },
  ky: {
    home: "Башкы бет", courses: "Курстар", library: "Китепкана", progress: "Жыйынтыктар",
    profile: "Профиль", welcome: "Билим алууну бүгүн баштаңыз", subtitle: "Баскыч-баскыч менен үйрөнүп, машыгып, ийгилигиңизди байкаңыз.",
    explore: "Курстарды көрүү", featured: "Сунушталган курстар", all: "Бардык курстар",
    continue: "Окууну улантуу", lessons: "сабак", beginner: "Башталгыч", intermediate: "Орто",
    arabic: "Араб тили", grammar: "Араб грамматикасы", reading: "Кыраат жана окуу",
    tests: "Тесттер", certificate: "Сертификат", free: "Акысыз", start: "Баштоо",
    search: "Курс же сабак издөө...", demo: "Демо режим", backend: "Сервер туташа элек"
  },
  ru: {
    home: "Главная", courses: "Курсы", library: "Библиотека", progress: "Прогресс",
    profile: "Профиль", welcome: "Начните учиться уже сегодня", subtitle: "Изучайте последовательно, практикуйтесь и отслеживайте свой результат.",
    explore: "Смотреть курсы", featured: "Рекомендуемые курсы", all: "Все курсы",
    continue: "Продолжить обучение", lessons: "уроков", beginner: "Начальный", intermediate: "Средний",
    arabic: "Арабский язык", grammar: "Арабская грамматика", reading: "Чтение и кираат",
    tests: "Тесты", certificate: "Сертификат", free: "Бесплатно", start: "Начать",
    search: "Поиск курса или урока...", demo: "Демо-режим", backend: "Сервер ещё не подключён"
  }
} as const;
